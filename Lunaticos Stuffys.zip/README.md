# lunatico stuffy datapack
the offical data pack to craft, use, and wear the stuffys!
thank you minimoth for teaching me how to make this, wouldnt be possible without you
